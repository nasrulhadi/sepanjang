<div class="content-base tinggi-350">
    <h3 class="content-tittle">Panduan Pembelian</h3>
    <div class="content-submenu">
        <div class="pull-right back-to-home"><?php echo CHtml::link('<span class="glyphicon glyphicon-home"></span> Beranda', array('/go/home')); ?></div>
        <ul class="list-submenu">
            <li><?php echo CHtml::link('Panduan', array('/halaman/panduan'), array('class' => 'active')); ?></li>
            <li><?php echo CHtml::link('Pertanyaan Umum', array('/halaman/panduan/faq'), array('class' => '')); ?></li>
        </ul>
    </div>
    <div class="content-core">
        <div class="alert alert-info"><strong>Wohooo!</strong> Halaman ini sedang proses pengerjaan. Sabar :)</div>
    </div>
</div>