<div class="content-base tinggi-350">
    <h3 class="content-tittle">Total Transaksi</h3>
    <div class="content-submenu">
        <div class="pull-right back-to-home"><?php echo CHtml::link('<span class="glyphicon glyphicon-home"></span> Beranda', array('/go/home')); ?></div>
        <ul class="list-submenu">
            <li><?php echo CHtml::link('Informasi Sistem', array('/halaman/sistem'), array('class' => '')); ?></li>
        	<li><?php echo CHtml::link('Total Transaksi', array('/halaman/sistem/transaksi'), array('class' => 'active')); ?></li>
        </ul>
    </div>
    <div class="content-core">
        <div class="alert alert-info"><strong>Wohooo!</strong> Halaman ini sedang proses pengerjaan. Sabar :)</div>
    </div>
</div>