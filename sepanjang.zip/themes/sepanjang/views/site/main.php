<?php
	$this->pageTitle=Yii::app()->name;
?>
