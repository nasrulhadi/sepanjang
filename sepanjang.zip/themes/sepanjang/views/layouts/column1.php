<?php

$this->beginContent('//layouts/main'); 

echo $content;

$this->endContent(); 

?>